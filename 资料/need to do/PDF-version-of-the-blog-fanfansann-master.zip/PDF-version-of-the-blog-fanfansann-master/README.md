我的所有优质博客全部开源啦（我自己原创的《ACM模板》《算法全家桶》《算法竞赛中的初等数论》 PDF免费下载）
https://blog.csdn.net/weixin_45697774/article/details/121304739?spm=1001.2014.3001.5501

# 取完之后记得给个Star哦！！

GitHub 下载文件不方便的话可以使用百度云盘下载：

《算法竞赛中的初等数论》

链接：https://pan.baidu.com/s/1oIQ0Q6G0ELAE4JfbGf5sMA 
提取码：haha 


《繁凡的ACM算法全家桶》

链接：https://pan.baidu.com/s/1jipseHao6eCUnv-ULC8E1g 
提取码：0ilp  

《繁凡的ACM模板》

链接：https://pan.baidu.com/s/1w4SFm1ugYsEQWcf71kDeTA 
提取码：wnti  

繁凡的《数据结构》 全书知识梳理

链接：https://pan.baidu.com/s/14qD1h7IT45hsQ8SZ4fWCVA 
提取码：is45  
